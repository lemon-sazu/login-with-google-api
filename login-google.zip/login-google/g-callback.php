<?php
	require_once "config.php";
	if (isset($_SESSION['access_token'])){
		$gClient->setAccessToken($_SESSION['access_token']);
}else if (isset($_GET['code'])) {
		$token = $gClient->fetchAccessTokenWithAuthCode($_GET['code']);
		$_SESSION['access_token'] = $token;
	} else {
		header('Location: login.php');
		exit();
	}
	$oAuth = new Google_Service_Oauth2($gClient);
	$userData = $oAuth->userinfo_v2_me->get();
	
	$_SESSION['id'] = $userData['id'];
	$_SESSION['email'] = $userData['email'];
	$_SESSION['picture'] = $userData['picture'];
	$_SESSION['familyName'] = $userData['familyName'];
	$_SESSION['givenName'] = $userData['givenName'];
	 $fullname = $userData['givenName'] .' '. $userData['familyName'];
	$email = $userData['email'];
	$pic =  $userData['picture'];
	$access= $userData['id'];

	
	$check = "SELECT * FROM google_user WHERE access_id = '$access'";
	$sql_check = $con->query($check);
	if($sql_check->num_rows>0){
		header('Location: index.php');
	}else{
		
		$sql="insert into google_user (name,email,picture,access_id) values
		('$fullname','$email','$pic', '$access')";
		   $res = $con->query($sql);
		   if($res){
			   header('Location: index.php');
		   }else{
			   echo mysqli_error($con);
		   }
	}


	exit();
?>